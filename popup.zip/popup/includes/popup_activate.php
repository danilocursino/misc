<?php

class Popup_Deactivate {
    public static function activate() {
        flush_rewrite_rules();
    }
}