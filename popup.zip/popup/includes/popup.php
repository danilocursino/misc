<?php
class Popup_Settings {
	private static $_instance = null;
	public $fields = [
		[
			'id' => 'field-popup-tipo',
			'label' => 'Tipo',
			'type' => 'select',
			'options' => [
				'img' => 'Imagem',
				'txt' => 'Texto',
			]
		],
		[
			'id' => 'field-popup-ativo',
			'label' => 'Ativo',
			'type' => 'select',
			'description' => 'desc',
			'options' => [
				'0' => 'Não',
				'1' => 'Sim',
			]
		],
		[
			'id' => 'field-id-color',
			'label' => 'Field Name',
			'description' => '',
			'type' => 'wysiwyg',
		],
	];
	public static function instance() {
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}
	
	function __construct() {
		add_action('admin_init', [$this, 'settings']);
		
		// Adicionar Popup ao menu
		add_action('admin_menu', function () {
			add_menu_page(
				'Popup',
				'Popup',
				'manage_options',
				'popup',
				[$this, 'popup_admin_page'],
				'dashicons-cover-image',
				1
			);
		});
	}


	function render_section(array $args) {}

	function settings() {

		// Adicionar configurações do Plugin
		register_setting('popup_settings', 'popup_options');
		
		// Registrar uma nova sessão de configurações
		add_settings_section(
			'popup_settings_section',
			__('Configurações', 'popup'),
			[$this, 'render_section'],
			'popup_settings'
		);

		// Registrar os campos do popup
		foreach ($this->fields as $field) {
			add_settings_field(
				$field['id'],
				$field['label'],
				[$this, 'render_field'],
				'popup_settings',
				'popup_settings_section',
				[
					'label_for' => $field['id'], /* The ID of the field. */
					'class' => 'wporg_row', /* The class of the field. */
					'field' => $field, /* Custom data for the field. */
				]
			);
		}
	}

	// HTML da página de Opções
	function popup_admin_page() { ?>
		<div class="wrap">
			<h1>Popup Automático | Tokio Marine</h1>

			<?php
				// Mensagem quando o popup for atualizado
				if (isset($_GET['settings-updated'])) {
					add_settings_error(
						'popup_messages',
						'popup_message',
						'Popup Atualizado - <a target="_blank" href="' . home_url() . '">Vizualizar</a>',
						'updated'
					);
				}

				settings_errors('popup_messages');
			?>

			<form action="options.php" method="post">
				<?php
					// Formulário de configurações
					settings_fields('popup_settings');
					do_settings_sections('popup_settings');
					submit_button('Salvar Configurações');
				?>
			</form>
	
		</div>
	<?php }


	function render_field(array $args): void
	{

		$field = $args['field'];

		$options = get_option('popup_options');

		switch ($field['type']) {

			case "text": {
				?>
				<input
					type="text"
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
					value="<?php echo isset($options[$field['id']]) ? esc_attr($options[$field['id']]) : ''; ?>"
				>
				<?php
				break;
			}

			case "checkbox": {
				?>
				<input
					type="checkbox"
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
					value="1"
				<?php echo isset($options[$field['id']]) ? (checked($options[$field['id']], 1, false)) : (''); ?>
				>
				<?php
				break;
			}

			case "textarea": {
				?>
				<textarea
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
				><?php echo isset($options[$field['id']]) ? esc_attr($options[$field['id']]) : ''; ?></textarea>
				<?php
				break;
			}

			case "select": {
				?>
				<select
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
				>
				<?php foreach ($field['options'] as $key => $option) { ?>
							<option value="<?php echo $key; ?>" 
							<?php echo isset($options[$field['id']]) ? (selected($options[$field['id']], $key, false)) : (''); ?>
							>
							<?php echo $option; ?>
							</option>
				<?php } ?>
				</select>
				<?php
				break;
			}

			case "password": {
				?>
				<input
					type="password"
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
					value="<?php echo isset($options[$field['id']]) ? esc_attr($options[$field['id']]) : ''; ?>"
				>
				<?php
				break;
			}

			case "wysiwyg": {
				wp_editor(
					isset($options[$field['id']]) ? $options[$field['id']] : '',
					$field['id'],
					array(
						'textarea_name' => 'wporg_options[' . $field['id'] . ']',
						'textarea_rows' => 5,
					)
				);
				break;
			}

			case "email": {
				?>
				<input
					type="email"
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
					value="<?php echo isset($options[$field['id']]) ? esc_attr($options[$field['id']]) : ''; ?>"
				>
				<?php
				break;
			}

			case "url": {
				?>
				<input
					type="url"
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
					value="<?php echo isset($options[$field['id']]) ? esc_attr($options[$field['id']]) : ''; ?>"
				>
				<?php
				break;
			}

			case "color": {
				?>
				<input
					type="color"
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
					value="<?php echo isset($options[$field['id']]) ? esc_attr($options[$field['id']]) : ''; ?>"
				>
				<?php
				break;
			}

			case "date": {
				?>
				<input
					type="date"
					id="<?php echo esc_attr($field['id']); ?>"
					name="wporg_options[<?php echo esc_attr($field['id']); ?>]"
					value="<?php echo isset($options[$field['id']]) ? esc_attr($options[$field['id']]) : ''; ?>"
				>
				<?php
				break;
			}
		}

		if (isset($field['description'])) { ?>
			<p class="description">
				<?php esc_html_e($field['description'], 'booking-hub'); ?>
			</p>
		<?php }
	}
}

Popup_Settings::instance();
