<?php

class Popup_Deactivate {
    public static function deactivate() {
        flush_rewrite_rules();
    }
}