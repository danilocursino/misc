<?php
/**
    * Plugin Name: Auto Popup
    * Plugin URI: https://tokiomarine.com.br
    * Description: Popup automático e personalizados para comunicação nos portais Tokio Marine. Com suporte para texto e imagens.
    * Version: 1.0.0
    * Author: Tokio Marine - Inovações e Canais Digitais
    * Author URI: https://tokiomarine.com.br/
    * License: GPL-2.0+
    * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
    * Text Domain: popup
    * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'POPUP_PATH', plugin_dir_path( __FILE__ ) );
define( 'POPUP_URL', plugin_dir_url( __FILE__ ) );
define( 'POPUP_VERSION', get_file_data( __FILE__, array('Version' => 'Version'), false)['Version'] );

require_once POPUP_PATH . 'plugin.php';